;(function($){

    var font_select_picker = '.axi-font-field',
        font_select_args   = {
            insertPreviewText : true,
            googleFontsPrefix : '_gof_',          // Google fonts prefix
            systemFontsPrefix : '_sys_',          // System fonts prefix
            geaFontsPrefix    : '_gea_',          // Google Early Access fonts prefix
            customFontsPrefix : '_cus_',          // Custom fonts prefix

            useGoogleFonts  : true,           // whether load google fonts
            systemFonts     : auxin.admin.fonts.system.faces,           // system font list DS -> [..,{name:'', thickness:'300,bold,600'},..]
            geaFonts        : auxin.admin.fonts.google_early.faces,         // Google Early Access fonts DS -> [..,{name:'', thickness:'300,bold,600', url:''},..]
            customFonts     : auxin.admin.fonts.custom.faces,             // Custom fonts DS -> [..,{name:'', thickness:'300,bold,600', url:''},..]

            l10n : {                    // localization object
                previewTextLabel    : auxin.admin.fontSelector.previewTextLabel || 'Preview text:',
                fontLabel           : auxin.admin.fontSelector.fontLabel        || 'Font:',
                fontSizeLabel       : auxin.admin.fontSelector.fontSizeLabel    || 'Size:',
                fontStyleLabel      : auxin.admin.fontSelector.fontStyleLabel   || 'Style:',
                googleFonts         : auxin.admin.fontSelector.googleFonts      || 'Google Fonts',
                systemFonts         : auxin.admin.fontSelector.systemFonts      || 'System Fonts',
                geaFonts            : auxin.admin.fontSelector.geaFonts         || 'Google Early Access',
                customFonts         : auxin.admin.fontSelector.customFonts      || 'Custom Fonts'
            }

        };

    $( font_select_picker ).avertaFontSelector( font_select_args );


}(jQuery, window, document));