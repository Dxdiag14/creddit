=== Phlox Fonts - Popular custom fonts for Phlox theme ===
Contributors: averta
Donate link: http://averta.net/
Tags: phlox, auxin, auxin framework, custom fonts, farsi fonts, rtl fonts
Requires PHP: 5.3
Requires at least: 4.6
Tested up to: 4.9.1
Stable tag: 1.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html


Extra custom fonts for Phlox theme

== Description ==

= Overview =

When using a theme with auxin framework (like [Phlox Theme](http://averta.net/phlox/wordpress-theme/ "Phlox Theme")), this plugin adds custom fonts in easiest way to your WordPress site. Including System fonts, Google fonts, Google Early Access fonts and popular custom fonts.

>[Demo on Phlox Theme](http://averta.net/phlox/wordpress-theme/ "Live demos of Phlox Theme")

= Bundled Fonts =

** Farsi Fonts **
* Vazir © Saber Rastikerdar https://github.com/rastikerdar/vazir-font, SIL | v16.1.0
* Shabnam © Saber Rastikerdar http://github.com/rastikerdar/shabnam-font, SIL | v2.3.0
* TanhaFont © Saber Rastikerdar: https://github.com/rastikerdar/tanha-font, SIL | v0.8
* GandomFont © Saber Rastikerdar: https://github.com/rastikerdar/gandom-font, SIL | 0.5.1
* SahelFont © Saber Rastikerdar: https://github.com/rastikerdar/sahel-font, SIL | v1.0.0 alpha 12
* VazirCodeFont © Saber Rastikerdar: https://github.com/rastikerdar/vazir-code-font | v1.0.3
* DiroozFont © Saber Rastikerdar: https://github.com/rastikerdar/dirooz-font | v0.2.1


= Some working Samples =
* [Classic Blog](http://averta.net/phlox/wordpress-theme/demo/classic-blog/)
* [Journey Blog](http://averta.net/phlox/wordpress-theme/demo/journey/)
* [food](http://averta.net/phlox/wordpress-theme/demo/food/)


= Compatible Browsers =

* IE8+
* Firefox
* Safari
* Opera
* Chrome
* iOS browser
* Android browser



== Installation ==

= Minimum Requirements =

* WordPress 4.6 or greater
* PHP version 5.3.0 or greater
* MySQL version 5.0 or greater


**This plugin works the best in [Phlox Theme](http://averta.net/phlox/wordpress-theme/)**


= Automatic installation (easiest way) =

To do an automatic install of Phlox Fonts, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "Phlox Fonts" and click Search Plugins. Once you have found it you can install it by simply clicking "Install Now".


= Manual installation =

**Uploading in WordPress Dashboard**

1. Download `auxin-fonts.zip`
2. Navigate to the 'Add New' in the plugins dashboard
3. Navigate to the 'Upload' area
4. Select `auxin-fonts.zip` from your computer
5. Click 'Install Now'
6. Activate the plugin in the Plugin dashboard

**Using FTP**

1. Download `auxin-fonts.zip`
2. Extract the `auxin-fonts` directory to your computer
3. Upload the `auxin-fonts` directory to the `/wp-content/plugins/` directory
4. Activate the plugin in the Plugin dashboard

The WordPress codex contains [instructions on how to install a WordPress plugin](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).



= Updating =

You can use automatic update to update the plugin safely.


== Screenshots ==

1. Option page (If Not using Phlox theme)


== Changelog ==

= Version 1.0.0 / (28.12.2014) =
* initial release


== Upgrade Notice ==

= 1.0.0 =
