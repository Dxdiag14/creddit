<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die('No Naughty Business Please !');
}

// Abort loading if WordPress is upgrading
if ( defined( 'WP_INSTALLING' ) && WP_INSTALLING ) {
    return;
}

function auxin_fonts_register_to_phlox( $fonts ) {
    $fonts['custom']['faces'][] = array( 'name' => 'Behdad'  ,'title' => 'behdad'  , 'thickness' => 'normal'         , 'url' => FONTS_DIR . '/behdad/' . FONT_FACE_FILE );
    $fonts['custom']['faces'][] = array( 'name' => 'Dirooz'  ,'title' => 'dirooz'  , 'thickness' => 'normal'         , 'url' => FONTS_DIR . '/dirooz/' . FONT_FACE_FILE );
    $fonts['custom']['faces'][] = array( 'name' => 'Gandom'  ,'title' => 'gandom'  , 'thickness' => 'normal'         , 'url' => FONTS_DIR . '/gandom/' . FONT_FACE_FILE );
    $fonts['custom']['faces'][] = array( 'name' => 'Sahel'   ,'title' => 'sahel'   , 'thickness' => 'normal,bold'    , 'url' => FONTS_DIR . '/sahel/'  . FONT_FACE_FILE );
    $fonts['custom']['faces'][] = array( 'name' => 'Samim'   ,'title' => 'Samim'   , 'thickness' => 'normal,bold'    , 'url' => FONTS_DIR . '/samim/'  . FONT_FACE_FILE );
    $fonts['custom']['faces'][] = array( 'name' => 'Shabnam' ,'title' => 'Shabnam' , 'thickness' => '300,normal,bold', 'url' => FONTS_DIR . '/shabnam/'. FONT_FACE_FILE );
    $fonts['custom']['faces'][] = array( 'name' => 'Vazir'   ,'title' => 'Vazir'   , 'thickness' => '300,normal,bold', 'url' => FONTS_DIR . '/vazir/'  . FONT_FACE_FILE );

    return $fonts;
}

add_filter( 'auxin_get_fonts_list', 'auxin_fonts_register_to_phlox' );
