<?php get_header();
	wpqa_content();
get_footer();?>